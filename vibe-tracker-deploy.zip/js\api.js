// Firebase Functions 生產環境
const API_BASE_URL = 'https://us-central1-vibe-tracker-98ca59.cloudfunctions.net/api';

class HabitAPI {
    static async addRecord(habitName, date, completed, notes = '') {
        const response = await fetch(`${API_BASE_URL}/records`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                habit_name: habitName,
                date: date,
                completed: completed,
                notes: notes
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    }
    
    static async getRecords(days = 7, habitName = null) {
        let url = `${API_BASE_URL}/records?days=${days}`;
        if (habitName) {
            url += `&habit=${encodeURIComponent(habitName)}`;
        }
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    }
}